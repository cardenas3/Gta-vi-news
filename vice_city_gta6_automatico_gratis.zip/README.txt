# VICE CITY — noticias automáticas GTA VI (coste objetivo: 0 €)

## Qué hace
- Comprueba feeds RSS públicos cada 30 minutos mediante GitHub Actions.
- Busca noticias relacionadas con GTA VI / GTA 6.
- Elimina duplicados por titular.
- Publica titulares y extractos en `docs/news.json`.
- La web carga el feed y abre el resumen dentro de la propia página.

## Qué NO hace
- No usa una IA de pago ni inventa resúmenes. El resumen es una selección/limpieza del extracto que facilita cada medio.
- No garantiza que todos los medios publiquen RSS ni que todos los feeds estén siempre disponibles.
- No copia artículos completos. Para leer el texto íntegro se conserva el enlace a la fuente.
- GitHub Free suele bastar para un proyecto personal público, pero los límites y condiciones de GitHub pueden cambiar.

## Cómo publicarlo gratis
1. Crea una cuenta en https://github.com si no tienes.
2. Crea un repositorio **público** llamado `vice-city-countdown`.
3. Descomprime este ZIP y sube TODO su contenido al repositorio, conservando `.github/workflows/`.
   - Si GitHub no muestra la carpeta `.github`, usa la carga de archivos desde la web o GitHub Desktop.
4. En el repositorio entra en **Settings → Pages** y en **Build and deployment → Source** selecciona **GitHub Actions**.
5. Entra en **Actions**, abre `Update GTA VI news` y pulsa **Run workflow** para lanzar la primera actualización.
6. Cuando termine el trabajo `deploy`, abre **Settings → Pages** y entra en la URL publicada.
7. En el iPhone abre esa URL con Safari y añádela a la pantalla de inicio.

## Actualización
GitHub Actions intentará actualizar la web cada 30 minutos. El horario de ejecución puede retrasarse por la cola de GitHub. También puedes ejecutarlo manualmente desde Actions → Update GTA VI news → Run workflow.

## Fuentes RSS configuradas
- Google News España: búsqueda GTA VI / GTA 6.
- Rockstar Newswire (si el feed RSS está disponible).
- Google News internacional: Grand Theft Auto VI.

Puedes editar la lista `FEEDS` en `fetch_news.py` para añadir o quitar fuentes RSS.

## Coste
No se necesita tarjeta ni clave API. La configuración propuesta utiliza funciones gratuitas. “Coste 0” depende de respetar los límites gratuitos de GitHub y las condiciones de las fuentes.
