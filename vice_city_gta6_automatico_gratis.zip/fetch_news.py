#!/usr/bin/env python3
"""Fetch public RSS feeds and publish short source-based summaries. No paid API."""
import json, re, html, urllib.request, xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path

OUT=Path("docs/news.json")
FEEDS=[
 ("Google News España","https://news.google.com/rss/search?q=GTA+VI+OR+GTA+6&hl=es&gl=ES&ceid=ES:es"),
 ("Rockstar Newswire","https://www.rockstargames.com/newswire?format=rss"),
 ("Google News Gaming","https://news.google.com/rss/search?q=Grand+Theft+Auto+VI&hl=en-US&gl=US&ceid=US:en"),
]
HEADERS={"User-Agent":"ViceCityFanNewsBot/1.0 (+public RSS reader)"}

def clean(s):
    s=html.unescape(re.sub(r"<[^>]+>"," ",s or ""))
    return re.sub(r"\s+"," ",s).strip()

def summarize(desc,title):
    text=clean(desc)
    # Keep the publisher-provided RSS excerpt; do not fabricate missing facts.
    if not text: return title
    sentences=re.split(r"(?<=[.!?])\s+",text)
    out=" ".join(sentences[:3]).strip()
    if len(out)>720: out=out[:717].rsplit(" ",1)[0]+"…"
    return out or title

def parse_date(s):
    try: return parsedate_to_datetime(s).astimezone(timezone.utc).isoformat()
    except Exception: return ""

items=[]; seen=set()
for source,feed in FEEDS:
    try:
        req=urllib.request.Request(feed,headers=HEADERS)
        with urllib.request.urlopen(req,timeout=20) as r: raw=r.read()
        root=ET.fromstring(raw)
        for item in root.findall(".//item"):
            title=clean(item.findtext("title"))
            link=clean(item.findtext("link"))
            desc=clean(item.findtext("description"))
            pub=item.findtext("pubDate") or ""
            low=(title+" "+desc).lower()
            if not title or not any(k in low for k in ("gta vi","gta 6","grand theft auto vi","grand theft auto 6")): continue
            key=re.sub(r"\W+","",title.lower())
            if key in seen: continue
            seen.add(key)
            dt=parse_date(pub)
            date=dt[:10] if dt else ""
            items.append({"title":title,"summary":summarize(desc,title),"summary_full":summarize(desc,title),
                          "url":link,"source":source,"date":date,"published_at":dt})
    except Exception as e:
        print(f"Feed warning ({source}): {e}")

items.sort(key=lambda x:x.get("published_at",""),reverse=True)
payload={"updated_at":datetime.now(timezone.utc).isoformat(),"items":items[:30]}
OUT.parent.mkdir(exist_ok=True)
OUT.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
print(f"Published {len(payload['items'])} news items to {OUT}")
